<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start">
            <p>2024 &copy; SPK - SAW Method</p>
        </div>
        <div class="float-end">
            <p>Crafted by Kelompok 3</ahref=></p>
        </div>
    </div>
</footer>
