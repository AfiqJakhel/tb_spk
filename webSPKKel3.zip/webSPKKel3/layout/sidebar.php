<div id="sidebar" class="active">
    <div class="sidebar-wrapper active">
        <div class="sidebar-header">
            <div class="d-flex flex-column align-items-center">
                <div class="logo">
                    <img src="assets/images/Unand.png" alt="Logo Unand" style="height: 150px; width:150px; margin-bottom:15px">
                </div>
                <div class="mt-2">
                    <a class="p-1 pe-3.5 text-light bg-body-tertiary rounded text-center d-block" href="./" style="background-color: skyblue;">Pemilihan BIMBEL</a>
                </div>
                <div class="toggler mt-2">
                    <a href="#" class="sidebar-hide d-xl-none d-block"><i class="bi bi-x bi-middle"></i></a>
                </div>
            </div>
        </div>
        <div class="sidebar-menu">
            <ul class="menu ">
                <li class="sidebar-title text-primary"><h4>Menu</h4></li>

                <li class="sidebar-item ">
                    <a href="./" class='sidebar-link' >
                        <i class="bi text-primary bi-grid-fill"></i>
                        <span class="text-primary">Dashboard</span>
                    </a>
                </li>

                <li class="sidebar-item">
                    <a href="alternatif.php" class='sidebar-link'>
                        <i class="bi text-primary bi-file-earmark-spreadsheet-fill"></i>
                        <span class="text-primary">Alternatif</span>
                    </a>
                </li>

                <li class="sidebar-item">
                    <a href="bobot.php" class='sidebar-link'>
                        <i class="bi text-primary bi-file-earmark-spreadsheet-fill"></i>
                        <span class="text-primary">Bobot & Kriteria</span>
                    </a>
                </li>

                <li class="sidebar-item">
                    <a href="matrik.php" class='sidebar-link'>
                        <i class="bi text-primary bi-pentagon-fill"></i>
                        <span class="text-primary">Matrik</span>
                    </a>
                </li>

                <li class="sidebar-item">
                    <a href="preferensi.php" class='sidebar-link'>
                        <i class="bi text-primary bi-bar-chart-fill"></i>
                        <span class="text-primary">Nilai Preferensi</span>
                    </a>
                </li>

                <li class="sidebar-item">
                    <a href="logout.php" class='sidebar-link'>
                        <i class="bi text-primary bi-box-arrow-right"></i>
                        <span class="text-primary">Logout</span>
                    </a>
                </li>

            </ul>
        </div>
        <button class="sidebar-toggler btn x"><i data-feather="x"></i></button>
    </div>
</div>
