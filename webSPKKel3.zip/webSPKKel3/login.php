<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - SAW</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="assets/vendors/bootstrap-icons/bootstrap-icons.css">
    <link rel="stylesheet" href="assets/css/app.css">
    <link rel="stylesheet" href="assets/css/pages/auth.css">
    <link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-icon">
</head>

<body>
    <div id="auth">

        <div class="bg-primary min-vh-100 d-flex align-items-center">
            <div class="container">
                <div class="row justify-content-center align-items-center">
                    <div class="col-lg-5 col-md-8 col-12">
                        <div id="auth-left" class="shadow-lg p-4 bg-light bg-body-tertiary rounded">
                            <h1 class="auth-title text-center">Welcome</h1>
                            <form action="login-act.php" method="post">
                                <div class="form-group position-relative mt-4 has-icon-left mb-4">
                                    <input type="text" class="form-control form-control-xl" placeholder="Username" name="username">
                                    <div class="form-control-icon">
                                        <i class="bi bi-person"></i>
                                    </div>
                                </div>
                                <div class="form-group position-relative has-icon-left mb-4">
                                    <input type="password" class="form-control form-control-xl" placeholder="Password" name="password">
                                    <div class="form-control-icon">
                                        <i class="bi bi-shield-lock"></i>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-block text-light btn-lg shadow-2xl mt-4" style="background-color: skyblue;">Login</button>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-6 d-none d-lg-block text-center">
                        <img class="img-fluid" style="max-height: 50%; max-width: 50%;" src="assets/images/Unand.png" alt="Logo Unand">
                    </div>
                </div>
            </div>
        </div>


    </div>
</body>

</html>
