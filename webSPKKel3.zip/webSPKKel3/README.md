# Sistem Pendukung Keputusan Manajer IT Terbaik dengan metode SAW (Simple Additive Weighting) menggunakan PHP dan MySQL
Metode Simple Additive Weighting (SAW) adalah salah satu teknik dalam analisis keputusan yang digunakan untuk membantu pengambilan keputusan dalam situasi di mana beberapa kriteria harus dipertimbangkan. Metode ini bertujuan untuk memberikan peringkat atau memilih alternatif terbaik dari sejumlah alternatif yang tersedia. Menurut Fishburn dan MacCrimmon dalam (Munthe, 2013) mengemukakan bahwa Metode Simple Additive Weight (SAW), sering juga dikenal dengan istilah metode penjumlahan terbobot. Konsep dasar metode Simple Additive Weight (SAW) adalah mencari penjumlahan terbobot dari rating kinerja pada setiap alternatif pada semua atribut.

Menurut Fishburn dan MacCrimmon dalam (Munthe, 2013) Ada beberapa langkah dalam penyelesaian metode Simple Additive Weight (SAW) adalah sebagai berikut:

1. Menentukan alternatif, yaitu Ai.
2. Menentukan kriteria-kriteria yang dijadikan acuan dalam pendukung keputusan yaitu Ci.
3. Menentukan rating kecocokan setiap alternatif pada setiap kriteria.
4. Membuat matriks keputusan berdasarkan kriteria (Ci).
5. Kemudian melakukan normalisasi matriks berdasarkan persamaan yang disesuaikan dengan jenis atribut (atribut keuntungan maupun atribut biaya) sehingga diperoleh matriks ternormalisasi R.
6. Hasil akhir diperoleh dari proses perangkingan yaitu penjumlahan dari perkalian matriks ternormalisasi R dengan vector bobot sehingga diperoleh nilai terbesar yang dipilih sebagai alternatis terbaik (Ai) sebagi solusi.

# Catatan
1. Sebelum memulai web import database di db\tb_spk.sql terlebih dahulu ke database
2. Lalu sesuaikan nama db di include\conn.php
3. Kemudian jalankan program di localhost/namaFolder
