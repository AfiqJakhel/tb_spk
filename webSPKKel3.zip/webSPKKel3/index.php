<!DOCTYPE html>
<html lang="en">
    <?php require "layout/head.php";?>

    <body>
        <div id="app">
            <?php require "layout/sidebar.php";?>
            <div id="main" class="bg-body">
                <header class="mb-3">
                    <a href="#" class="burger-btn d-block d-xl-none">
                        <i class="bi bi-justify fs-3"></i>
                    </a>
                </header>
                <div class="page-heading">
                    <h1 class="ms-3 p-3 text-light bg-body-tertiary rounded" style="background-color: skyblue; text-align:center">Dashboard</h1>
                </div>
                <div class="page-content">
                    <section class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header" style="text-align: center;">
                                    <h4 style="color: black;">Sistem Penunjang Keputusan Pemilihan Tempat BIMBEL Menggunakan Metode SAW di Indonesia</h4>
                                </div>
                                <div class="card-content">
                                    <div class="card-body">
                                        <p class="card-text">
                                        <h5 style="color: black;">Nama Anggota Kelompok:</h5>
                                        <br>
                                        <ol type="1" style="color: black;">
                                            <li>Muhammad Diaz Ananda Syukri (2311521015)</li>
                                            <li>Muhammad Nabeel Ghani (2311523010)</li>
                                            <li>Muhammad Afiq Jakhel (2311523011)</li>
                                            <li>Bening Fatih Athaya (2311523015)</li>
                                            <li>Muhammad Farid Junaidi (2311523027)</li>
                                        </ol>
                                        <br>
                                        </p>
                                        <hr>
                                        <p class="card-text" style="color: black;">
                                        Metode Simple Additive Weighting (SAW) merupakan salah satu teknik dalam analisis keputusan yang digunakan untuk membantu memilih alternatif terbaik dari beberapa pilihan dengan mempertimbangkan berbagai kriteria. Menurut Fishburn dan MacCrimmon dalam (Munthe, 2013), metode ini juga dikenal sebagai metode penjumlahan terbobot. Konsep utama dari metode Simple Additive Weighting (SAW) adalah menghitung jumlah terbobot dari nilai kinerja setiap alternatif berdasarkan seluruh atribut yang ada.
                                        </p>
                                        <hr>
                                        <p class="card-text" style="color: black;">
                                        Menurut Fishburn dan MacCrimmon dalam (Munthe, 2013) Ada beberapa langkah dalam penyelesaian metode Simple Additive Weight (SAW) adalah sebagai berikut:
                                        </p>
                                        <ol type="1" style="color: black;">
                                            <li>Menentukan alternatif, yaitu Ai.</li>
                                            <li>Menentukan kriteria-kriteria yang dijadikan acuan dalam pendukung keputusan yaitu Ci.</i>
                                            <li>Menentukan rating kecocokan setiap alternatif pada setiap kriteria.</li>
                                            <li>Membuat matriks keputusan berdasarkan kriteria (Ci).</li>
                                            <li>Kemudian melakukan normalisasi matriks berdasarkan persamaan yang disesuaikan dengan jenis atribut (atribut keuntungan maupun atribut biaya) sehingga diperoleh matriks ternormalisasi R.</li>
                                            <li>Hasil akhir diperoleh dari proses perangkingan yaitu penjumlahan dari perkalian matriks ternormalisasi R dengan vector bobot sehingga diperoleh nilai terbesar yang dipilih sebagai alternatis terbaik (Ai) sebagi solusi.</li>
                                        </ol>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
                
            </div>
        </div>
        <?php require "layout/js.php";?>
    </body>

</html>